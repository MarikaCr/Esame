package com.esame.EsameTecnicoPratico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsameTecnicoPraticoApplicationTests {

	@Test
	void contextLoads() {
	}

}
