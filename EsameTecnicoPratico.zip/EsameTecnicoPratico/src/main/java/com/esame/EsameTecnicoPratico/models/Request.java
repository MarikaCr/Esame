package com.esame.EsameTecnicoPratico.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Request {
	
	private Integer annoInizio;
	private Integer annoFine;

}
