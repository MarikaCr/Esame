package com.esame.EsameTecnicoPratico.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "variazioni_occupazione")
public class VariazioneOccupazione {

	@Id
	@GeneratedValue
	private Integer anno;

	private double nordovest;
	private double nordest;
	private double centro;
	private double sud;
	private double isole;
	private double nazionale;
	
	
}
