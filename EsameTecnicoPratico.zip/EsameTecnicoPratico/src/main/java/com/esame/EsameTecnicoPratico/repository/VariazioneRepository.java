package com.esame.EsameTecnicoPratico.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.esame.EsameTecnicoPratico.entity.Produttivita;
import com.esame.EsameTecnicoPratico.entity.VariazioneOccupazione;

public interface VariazioneRepository extends JpaRepository<VariazioneOccupazione, Integer>{
	
	@Query(value = "SELECT * FROM variazioni_occupazione WHERE anno >= :annoInizio AND anno <= :annoFine", nativeQuery = true )
	List<VariazioneOccupazione> variazioneOccupazioneAree(@Param("annoInizio") Integer annoInizio, @Param("annoFine") Integer annoFine);
	
	@Query(value = "SELECT nazionale FROM produttivita WHERE anno >= :annoInizio AND anno <= :annoFine", nativeQuery = true)
	List<VariazioneOccupazione> variazioneOccupazioneArea(@Param("annoInizio") Integer annoInizio, @Param("annoFine") Integer annoFine, @Param("area") String area);

}
