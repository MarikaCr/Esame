package com.esame.EsameTecnicoPratico.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.esame.EsameTecnicoPratico.entity.ValoriAggiunti;

public interface ValoriRepository extends JpaRepository<ValoriAggiunti, Integer>{

}
