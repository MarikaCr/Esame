package com.esame.EsameTecnicoPratico.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.esame.EsameTecnicoPratico.entity.ValoriAggiunti;

public interface ValoriRepository extends JpaRepository<ValoriAggiunti, Integer>{
	
	@Query(value = "SELECT * FROM valori_aggiunti WHERE anno >= :annoInizio AND anno <= :annoFine", nativeQuery = true)
	List<ValoriAggiunti> mediaValoriAree(@Param("annoInizio") Integer annoInizio, @Param("annoFine") Integer annoFine);
		

}
