package com.esame.EsameTecnicoPratico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EsameTecnicoPraticoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EsameTecnicoPraticoApplication.class, args);
	}

}
