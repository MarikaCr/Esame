package com.esame.EsameTecnicoPratico.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.esame.EsameTecnicoPratico.entity.Produttivita;
import com.esame.EsameTecnicoPratico.entity.ValoriAggiunti;
import com.esame.EsameTecnicoPratico.entity.VariazioneOccupazione;
import com.esame.EsameTecnicoPratico.models.Request;
import com.esame.EsameTecnicoPratico.models.RequestArea;
import com.esame.EsameTecnicoPratico.repository.ProduttivitaRepository;
import com.esame.EsameTecnicoPratico.repository.ValoriRepository;
import com.esame.EsameTecnicoPratico.repository.VariazioneRepository;

@Service
public class APIService {

	@Autowired
	private ProduttivitaRepository produttivitaRepo;
	
	@Autowired
	private ValoriRepository valoriRepo;
	
	@Autowired
	private VariazioneRepository variazioneRepo;
	
	public List<Produttivita> produttivitaAree(Request request) {
		List<Produttivita> lista = produttivitaRepo.trovaProduttivitaAree(request.getAnnoInizio(), request.getAnnoFine());
		return lista;
	}
	
	public List<Produttivita> produttivitaNazionale(Request request) {
		List<Produttivita> list = produttivitaRepo.trovaProduttivitaNazionale(request.getAnnoInizio(), request.getAnnoFine());
		return list;
	}
	
	public List<ValoriAggiunti> mediaValoriPerAree(Request request) {
		List<ValoriAggiunti> list = valoriRepo.mediaValoriAree(request.getAnnoInizio(), request.getAnnoFine());
		return list;
	}
	
	public List<VariazioneOccupazione> mediaVariazioneAree(Request request) {
		List<VariazioneOccupazione> list = variazioneRepo.variazioneOccupazioneAree(request.getAnnoInizio(), request.getAnnoFine());
		return list;
	}
	
	public List<VariazioneOccupazione> mediaVariazioneArea(RequestArea request) {
		List<VariazioneOccupazione> list = variazioneRepo.variazioneOccupazioneArea(request.getAnnoInizio(), request.getAnnoFine(), request.getArea());
		return list;
	}
	
	
}
