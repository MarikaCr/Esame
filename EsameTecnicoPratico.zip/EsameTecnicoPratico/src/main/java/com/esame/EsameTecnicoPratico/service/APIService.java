package com.esame.EsameTecnicoPratico.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.esame.EsameTecnicoPratico.entity.Produttivita;
import com.esame.EsameTecnicoPratico.models.Request;
import com.esame.EsameTecnicoPratico.repository.ProduttivitaRepository;
import com.esame.EsameTecnicoPratico.repository.ValoriRepository;
import com.esame.EsameTecnicoPratico.repository.VariazioneRepository;

@Service
public class APIService {

	@Autowired
	private ProduttivitaRepository produttivitaRepo;
	
	@Autowired
	private ValoriRepository valoriRepo;
	
	@Autowired
	private VariazioneRepository variazioneRepo;
	
	public List<Produttivita> produttivitaAree(Request request) {
		List<Produttivita> lista = produttivitaRepo.trovaProduttivitaAree(request.getAnnoFine(), request.getAnnoFine());
		return lista;
	}
	
	public List<Produttivita> produttivitaNazionale(Request request) {
		List<Produttivita> list = produttivitaRepo.trovaProduttivitaNazionale(request.getAnnoFine(), request.getAnnoFine());
		return list;
	}
	
	
}
