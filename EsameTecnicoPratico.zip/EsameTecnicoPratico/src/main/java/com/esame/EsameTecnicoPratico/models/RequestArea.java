package com.esame.EsameTecnicoPratico.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequestArea extends Request{
	
	private String area;

}
