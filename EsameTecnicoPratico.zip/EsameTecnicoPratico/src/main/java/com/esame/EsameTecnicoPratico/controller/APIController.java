package com.esame.EsameTecnicoPratico.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esame.EsameTecnicoPratico.entity.Produttivita;
import com.esame.EsameTecnicoPratico.entity.ValoriAggiunti;
import com.esame.EsameTecnicoPratico.entity.VariazioneOccupazione;
import com.esame.EsameTecnicoPratico.models.Request;
import com.esame.EsameTecnicoPratico.models.RequestArea;
import com.esame.EsameTecnicoPratico.service.APIService;

@RestController
@RequestMapping("dati")
public class APIController {
	
	@Autowired
	private APIService service;
	
	@GetMapping("/produttivita_aree")
	public List<Produttivita> produttivitaAree(@RequestBody Request request) {
		return service.produttivitaAree(request);
		
	}
	
	@GetMapping("/produttivita_nazionale")
	public List<Produttivita> produttivitaNazionale(@RequestBody Request request) {
		return service.produttivitaNazionale(request);
	}
	
	@GetMapping("/media_valori")
	public List<ValoriAggiunti>  mediaValoriPerAree(@RequestBody Request request) {
		return service.mediaValoriPerAree(request);
	}

	@GetMapping("/variazione_aree")
	public List<VariazioneOccupazione> variazioneAree(Request request) {
		return service.mediaVariazioneAree(request);
	}
	
	@GetMapping("/variazione_area")
	public List<VariazioneOccupazione> variazioneArea(RequestArea request) {
		return service.mediaVariazioneArea(request);
	}

	
	
}
